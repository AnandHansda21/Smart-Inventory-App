
  # StockCall App Concept Document

  This is a code bundle for StockCall App Concept Document. The original project is available at https://www.figma.com/design/IFZUoViAM2Ai5FW7uOM9Zt/StockCall-App-Concept-Document.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  